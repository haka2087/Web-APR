<?php

$variable=$_GET["var"];
//$variable2=$_POST["var2"];
//$variable3=$_POST["var3"];

//$variable= 4;
//$variable2= 11111;
//$variable3= '2222222443556';

//$variable = 123;

//echo $variable;
//echo $variable2;
//echo $variable3;*/
$server = "localhost";
$username = "id9909986_pruebas";
$baseDatos = "id9909986_bd_pruebas";
$password = "agua2019";


$conexion = mysqli_connect($server,$username,$password,$baseDatos);

$update = mysqli_query($conexion, "SELECT * FROM usuario where id = $variable");

/*$idw = mysqli_query($conexion, "SELECT id FROM usuario order by id desc limit 1");
$row1=mysqli_fetch_array($idw);
$idw2=$row1[0];

$id = mysqli_query($conexion, "SELECT mes FROM registros order by id desc limit 1");
$row1=mysqli_fetch_array($id);
$id2=$row1[0];

$contador=1;
while($contador<=$idw2){
$medidores = mysqli_query($conexion, "SELECT medidor FROM usuario WHERE id = $contador");
$row2=mysqli_fetch_array($medidores);
$med=$row2[0];

echo $med;

$medodores2 = mysqli_query($conexion, "SELECT medidor FROM registros WHERE mes=$id2 and medidor=$med");
$row3=mysqli_fetch_array($medodores2);
$lect=$row3[0];

echo $lect;

if($lect != $med ){
    
    echo "Falta el registro del medidor ".$med;
    continue;
    
}else{
    
    echo "el regixtro existe";
    
}
$contador = $contador + 1;
}*/

//while ( $row=mysqli_fetch_array($update)) {
$row=mysqli_fetch_array($update);
printf ($row['medidor']);
printf (",");
printf ($row['nombre']);
printf (",");
printf ($row['apellido']);
printf (",");
printf ($row['rut']);
printf (",");
printf ($row['direccion']);
printf (",");
printf ($row['id']);


//}



mysqli_close($conexion);



 ?>